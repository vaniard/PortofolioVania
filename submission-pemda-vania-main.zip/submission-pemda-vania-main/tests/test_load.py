import pytest
from unittest.mock import patch, MagicMock
import pandas as pd
from utils.load import save_to_csv, save_to_google_sheets, save_to_postgresql

@pytest.fixture
def dummy_df():
    return pd.DataFrame({
        'Title': ['Product A'],
        'Price': [160000.0],
        'Rating': [4.5],
        'Colors': [2],
        'Size': ['M'],
        'Gender': ['Unisex'],
        'timestamp': ['2024-01-01T00:00:00']
    })

def test_save_to_csv(tmp_path, dummy_df):
    filepath = tmp_path / "test.csv"
    save_to_csv(dummy_df, filename=str(filepath))
    assert filepath.exists()

@patch("utils.load.service_account.Credentials.from_service_account_file")
@patch("utils.load.gspread")
def test_save_to_google_sheets(mock_gspread, mock_creds, dummy_df):
    # Setup mock credentials
    mock_creds.return_value = MagicMock()
    
    # Setup mock client
    mock_client = MagicMock()
    mock_gspread.authorize.return_value = mock_client
    
    # Setup mock spreadsheet
    mock_spreadsheet = MagicMock()
    mock_client.open.return_value = mock_spreadsheet

    # Buat class exception sederhana yang mewarisi Exception
    class MockWorksheetNotFound(Exception):
        pass
    
    class MockSpreadsheetNotFound(Exception):
        pass
    
    # Set exceptions ke mock gspread
    mock_gspread.exceptions = MagicMock()
    mock_gspread.exceptions.WorksheetNotFound = MockWorksheetNotFound
    mock_gspread.exceptions.SpreadsheetNotFound = MockSpreadsheetNotFound
    
    # Simulasikan worksheet tidak ditemukan dengan exception yang sudah di-mock
    mock_spreadsheet.worksheet.side_effect = MockWorksheetNotFound("Worksheet not found")
    
    # Setup mock untuk worksheet baru
    mock_worksheet = MagicMock()
    mock_spreadsheet.add_worksheet.return_value = mock_worksheet
    
    # Mock set_with_dataframe
    with patch("utils.load.set_with_dataframe") as mock_set:
        # Panggil fungsi
        save_to_google_sheets(dummy_df, creds_path="fake-creds.json")
        
        # Verifikasi add_worksheet dipanggil (karena worksheet tidak ditemukan)
        mock_spreadsheet.add_worksheet.assert_called_once_with(
            title="Sheet1", 
            rows=100, 
            cols=20
        )
        
        # Verifikasi clear dan set_with_dataframe dipanggil
        mock_worksheet.clear.assert_called_once()
        mock_set.assert_called_once_with(mock_worksheet, dummy_df)

@patch("utils.load.create_engine")
def test_save_to_postgresql(mock_create_engine, dummy_df):
    # Setup mock engine
    mock_engine = MagicMock()
    mock_create_engine.return_value = mock_engine
    
    # Mock koneksi
    mock_conn = MagicMock()
    mock_engine.connect.return_value.__enter__.return_value = mock_conn
    
    # Panggil fungsi
    save_to_postgresql(dummy_df)
    
    # Verifikasi to_sql dipanggil
    mock_engine.connect.assert_called_once()