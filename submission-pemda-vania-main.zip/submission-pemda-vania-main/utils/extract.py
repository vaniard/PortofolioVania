import requests
from bs4 import BeautifulSoup
from datetime import datetime
import pandas as pd
import re 

def scrape_main(base_url="https://fashion-studio.dicoding.dev", max_pages=50):
    data = []
    timestamp = datetime.now().isoformat()

    for page in range(1, max_pages + 1):
        url = base_url if page == 1 else f"{base_url}/page{page}"
        print(f"Mengekstrak data {url} ...")

        try:
            res = requests.get(url, timeout=10)

            if res.status_code == 404:
                print(f"Halaman {page} mengembalikan error 404. Proses pagination dihentikan.")
                break

            res.raise_for_status()
            soup = BeautifulSoup(res.text, "html.parser")

            products = soup.find_all("div", class_="product-details")

            if not products:
                print(f"Tidak ada produk yang ditemukan pada halaman {page}. Proses dihentikan.")
                break

            for product in products:
                try:
                    title_tag = product.find("h3", class_="product-title")
                    price_tag = product.find("span", class_="price")
                    
                    rating_tag = product.find('p', string=re.compile(r'Rating', re.IGNORECASE))
                   
                    colors_tag = product.find('p', string=re.compile(r'Colors?', re.IGNORECASE)) 
                    
                    size_tag = product.find('p', string=re.compile(r'Size', re.IGNORECASE))
                   
                    gender_tag = product.find('p', string=re.compile(r'Gender', re.IGNORECASE))

                    title = title_tag.get_text(strip=True) if title_tag else None
                    price = price_tag.get_text(strip=True) if price_tag else None
                    
                    # Untuk rating, kita ambil teks utuhnya dulu, nanti bisa dibersihkan jika perlu
                    rating = rating_tag.get_text(strip=True) if rating_tag else None
                    colors = colors_tag.get_text(strip=True) if colors_tag else None
                    size = size_tag.get_text(strip=True) if size_tag else None
                    gender = gender_tag.get_text(strip=True) if gender_tag else None

                    data.append({
                        "Title": title,
                        "Price": price,
                        "Rating": rating,  # Akan berisi teks seperti "Rating: ⭐ 3.9 / 5"
                        "Colors": colors,
                        "Size": size,
                        "Gender": gender,
                        "timestamp": timestamp
                    })
                except Exception as e:
                    print(f"Terjadi kesalahan saat memproses data produk pada halaman. {page}: {e}")

        except Exception as e:
            print(f"Gagal mengambil halaman. {page}: {e}")
            break  

    df = pd.DataFrame(data)
    if df.empty:
        print("Peringatan: Tidak ada data yang berhasil diambil. DataFrame kosong.")
    return df

def main():
    """Fungsi utama untuk menjalankan proses scraping dan menampilkan data."""
    base_url = 'https://fashion-studio.dicoding.dev'
    product_data = scrape_main(base_url, max_pages=3)

    # Perbaikan: gunakan .empty untuk mengecek DataFrame kosong
    if not product_data.empty:
        print(product_data)
    else:
        print("Tidak ada data yang ditemukan.")

if __name__ == "__main__":
    main()