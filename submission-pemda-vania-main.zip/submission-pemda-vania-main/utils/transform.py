import pandas as pd
import numpy as np

def transform_data(df):
    try:
        df = df.copy()

        # Hapus produk tidak dikenal
        df = df[~df['Title'].str.contains("Unknown Product", na=False)]

        # Transformasi Price
        df['Price'] = (
            df['Price']
            .fillna("0")
            .str.replace("Price Unavailable", "0", regex=False)
            .str.replace(r"[\$,]", "", regex=True)
            .astype(float) * 16000
        )

        # Transformasi Rating
        df['Rating'] = df['Rating'].str.extract(r'(\d+\.?\d*)').astype(float)

        # Transformasi Colors
        df['Colors'] = df['Colors'].str.extract(r'(\d+)').astype(float).astype('Int64')

        # Transformasi Size dan Gender
        df['Size'] = df['Size'].str.replace("Size: ", "", regex=False).str.strip()
        df['Gender'] = df['Gender'].str.replace("Gender: ", "", regex=False).str.strip()

        # Hapus duplikat berdasarkan Title
        df.drop_duplicates(subset=['Title'], keep='first', inplace=True)

        # Hapus baris dengan Price 0 (jika dianggap tidak valid)
        df = df[df['Price'] > 0]

        # Reset index setelah semua operasi
        df.reset_index(drop=True, inplace=True)

        return df

    except Exception as e:
        print(f"Kesalahan terjadi saat proses transformasi data: {e}")
        return pd.DataFrame()