import pandas as pd
import gspread
from google.oauth2 import service_account
from sqlalchemy import create_engine
from gspread_dataframe import set_with_dataframe  # Pindahkan import ke atas
from google.oauth2.service_account import Credentials

# Menyimpan data dalam format .csv
def save_to_csv(df, filename="products.csv"):
    try:
        df.to_csv(filename, index=False)
        print(f"File CSV berhasil disimpan sebagai {filename}")
    except Exception as e:
        print(f"Gagal menyimpan file CSV: {e}")

# Menyimpan data ke google sheets
def save_to_google_sheets(df, spreadsheet_name="fashion studio", worksheet_name="Sheet1", creds_path="vania-project.json"):
    try:
        # Scope akses Google Sheets
        scope = ["https://www.googleapis.com/auth/spreadsheets",
                 "https://www.googleapis.com/auth/drive"]

        # Autentikasi dengan credentials JSON
        creds = Credentials.from_service_account_file(creds_path, scopes=scope)
        client = gspread.authorize(creds)

        # Buka spreadsheet
        spreadsheet = client.open(spreadsheet_name)

        # Pilih worksheet
        try:
            worksheet = spreadsheet.worksheet(worksheet_name)
            print(f"Menggunakan worksheet yang sudah ada: {worksheet_name}")
        except gspread.exceptions.WorksheetNotFound:
            worksheet = spreadsheet.add_worksheet(title=worksheet_name, rows=100, cols=20)
            print(f"Membuat worksheet baru: {worksheet_name}")

        # Kosongkan sheet dan tulis data baru
        worksheet.clear()
        set_with_dataframe(worksheet, df)
        print(f"Data berhasil disimpan ke Google Sheets: {spreadsheet_name} - {worksheet_name}")

    except gspread.exceptions.SpreadsheetNotFound:
        print(f"Spreadsheet '{spreadsheet_name}' tidak ditemukan. Pastikan nama spreadsheet benar dan sudah di-share ke service account.")
    except FileNotFoundError:
        print(f"File credentials '{creds_path}' tidak ditemukan. Pastikan file ada di direktori yang benar.")
    except Exception as e:
        print(f"Gagal menyimpan ke Google Sheets: {e}")

# Menyimpan data ke PostgreSQL
def save_to_postgresql(df, db_url="postgresql://postgres:@localhost:5432/fashion_studios", table_name="products"):
    try:
        engine = create_engine(db_url)
        
        # Test koneksi
        with engine.connect() as conn:
            print("Koneksi ke database berhasil")
        
        # Simpan data
        df.to_sql(table_name, engine, if_exists='replace', index=False)
        print(f"Data berhasil disimpan ke PostgreSQL, tabel: {table_name}")
        
    except Exception as e:
        print(f"Gagal menyimpan ke PostgreSQL: {e}")