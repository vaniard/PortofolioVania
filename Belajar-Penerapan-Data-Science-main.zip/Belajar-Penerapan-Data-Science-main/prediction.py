import pandas as pd
import numpy as np
import joblib
from sklearn.preprocessing import MinMaxScaler, LabelEncoder

df_original = pd.read_csv('/content/employee_data.csv')
# Menghilangkan baris dengan nilai yang hilang pada kolom 'Attrition'
df_original.dropna(inplace=True)
# Menghapus kolom yang tidak diperlukan
df_original.drop(columns=['EmployeeCount', 'Over18', 'StandardHours', 'EmployeeId'], inplace=True)

# Mengubah nilai kolom Attrition menjadi "Yes" dan "No" (jika belum dilakukan)
if 'Attrition' in df_original.columns:
    df_original['Attrition'] = df_original['Attrition'].replace({1: 'Yes', 0: 'No'})

# Mendefinisikan kamus pemetaan
education_map = {1: 'Below College', 2: 'College', 3: 'Bachelor', 4: 'Master', 5: 'Doctor'}
satisfaction_map = {1: 'Low', 2: 'Medium', 3: 'High', 4: 'Very High'}
performance_map = {1: 'Low', 2: 'Good', 3: 'Excellent', 4: 'Outstanding'}
worklife_map = {1: 'Low', 2: 'Good', 3: 'Excellent', 4: 'Outstanding'}

# Menerapkan pemetaan ke kolom yang sesuai dan menyimpannya sebagai category
df_original['Education'] = df_original['Education'].map(education_map).astype('category')
df_original['EnvironmentSatisfaction'] = df_original['EnvironmentSatisfaction'].map(satisfaction_map).astype('category')
df_original['JobInvolvement'] = df_original['JobInvolvement'].map(satisfaction_map).astype('category')
df_original['JobSatisfaction'] = df_original['JobSatisfaction'].map(satisfaction_map).astype('category')
df_original['PerformanceRating'] = df_original['PerformanceRating'].map(performance_map).astype('category')
df_original['RelationshipSatisfaction'] = df_original['RelationshipSatisfaction'].map(satisfaction_map).astype('category')
df_original['WorkLifeBalance'] = df_original['WorkLifeBalance'].map(worklife_map).astype('category')

# Mengubah kolom kategorikal menjadi numerik menggunakan LabelEncoder
# Include the columns that were mapped to categories
categorical_cols_for_encoding = [
    'BusinessTravel',
    'Department',
    'EducationField',
    'Gender',
    'JobRole',
    'MaritalStatus',
    'OverTime',
    'Education',
    'EnvironmentSatisfaction',
    'JobInvolvement',
    'JobSatisfaction',
    'PerformanceRating',
    'RelationshipSatisfaction',
    'WorkLifeBalance'
]

label_encoders = {}
for col in categorical_cols_for_encoding:
    if col in df_original.columns:
        le = LabelEncoder()

        df_original[col] = le.fit_transform(df_original[col].astype(str)) # Ensure they are strings for LabelEncoder
        label_encoders[col] = le

new_employee_data = df_original.drop('Attrition', axis=1).sample(5, random_state=42) # Ambil 5 sampel acak

# Pastikan urutan kolom sama dengan data training
X_train_cols = df_original.drop('Attrition', axis=1).columns
new_employee_data = new_employee_data[X_train_cols]

# --- End Bagian Simulasi Data Baru ---

# Memuat model yang sudah disimpan
try:
    loaded_model = joblib.load('model_smaller.jlb')
    print("Model berhasil dimuat.")
except FileNotFoundError:
    print("Error: File model 'model_smaller.jlb' tidak ditemukan.")
    print("Pastikan Anda telah menyimpan model dengan nama tersebut dan berada di direktori yang benar.")
    exit()

scaler = MinMaxScaler()
X_for_scaler_fitting = df_original.drop('Attrition', axis=1)
scaler.fit(X_for_scaler_fitting) # Melatih scaler dengan seluruh data yang sudah di-preprocess

new_employee_data_scaled = scaler.transform(new_employee_data)

# Melakukan prediksi dengan model yang dimuat
predictions_numeric = loaded_model.predict(new_employee_data_scaled)

# Mengonversi prediksi numerik kembali ke label 'Yes'/'No'
# Kita perlu LabelEncoder untuk kolom 'Attrition' dari data asli untuk membalikkan transformasinya
attrition_le = LabelEncoder()
attrition_le.fit(df_original['Attrition'])
predictions_labels = attrition_le.inverse_transform(predictions_numeric)

print("\nHasil Prediksi:")
for i, prediction in enumerate(predictions_labels):
    print(f"Karyawan {i+1}: {prediction}")

# Tampilkan data karyawan yang diprediksi beserta prediksinya
result_df = new_employee_data.copy()
result_df['Predicted_Attrition'] = predictions_labels
print("\nData Karyawan dengan Prediksi Attrition:")
print(result_df)
