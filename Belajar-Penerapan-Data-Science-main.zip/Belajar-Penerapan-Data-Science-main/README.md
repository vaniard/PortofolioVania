# Proyek Akhir: Menyelesaikan Permasalahan Human Resources

## 1. Business Understanding 

### 1.1 Latar Belakang

Jaya Jaya Maju merupakan perusahaan multinasional yang berdiri sejak tahun 2000 dan kini memiliki lebih dari 1.000 karyawan yang tersebar di berbagai wilayah Indonesia. Seiring dengan pertumbuhan perusahaan yang semakin berkembang pesat dan cakupan operasional yang melebar luas, muncul sebuah tantangan baru dalam pengelolaan sumber daya manusia, salah satunya adalah tingginya tingkat attrition atau tingkat pergantian (turnover) karyawan. 

Tingkat attrition yang melebihi 10% menjadil sinyal bahwa cukup banyak karyawan yang memilih meninggalkan perusahaan. Turnover yang tinggi menyebabkan peningkatan biaya rekrutmen dan pelatihan, serta menurunkan produktivitas perusahaan. Oleh karena itu, pihak manajemen, khususnya divisi Human Resource (HR) berupaya untuk memahami lebih dalam mengenai faktor-faktor yang mendorong karyawan keluar. Dengan harapan dapat menekan angka attrition dan mempertahankan karyawan yang berkualitas serta berkomitmen. 

## 2. Permasalahan Bisnis 

1. Dengan tingkat attrition yang melebihi 10%, perusahaan harus menanggung tingginya biaya rekrutmen, pelatihan, serta kehilangan aset pengetahuan dan pengalaman dari karyawan yang keluar. Maka dari itu, diperlukan identifikasi faktor-faktor penyebab attrition guna menyusun strategi retensi yang lebih optimal.
2. Mengidentifikasi faktor-faktor yang mempengaruhi keputusan karyawan keluar.
3. Perusahaan dapat mengambil langkah untuk meningkatkan retensi terhadap karyawan.
4. Membuat dashboard bisnis. Dashboard tersebut diharapkan dapat memberikan gambaran yang jelas dan komprehensif tentang tingkat kepuasan kerja, pendidikan, demografis dan faktor-faktor risiko yang berpotensi meningkatkan attrition.

## 3. Cakupan Proyek 

1. Mengumpulkan dan memproses data : Mengimpor dan melakukan pembersihan data untuk memastikan data berkualitas baik, menangani nilai yang hilang, mengkonversi variabel kategorikal menjadi variabel numerik dengan teknik encoding.
2. Analisis deskriptif : Melakukan analisis untuk memahami distribusi data, mengidentifikasikan tren pada data dan menyajikannya dalam bentuk visualisasi data.
3. Analisis faktor attrition : Mengindetifikasikan faktor yang mempengaruhi attrition, menggunakan analisis korelasi untuk mencari hubungan antar variabel dan membangun model prediksi untuk mengidentifikasi karyawan yang berisiko mengalami attrition.
4. Membuat model prediksi : Menggunakan algoritma machine learning untuk membangun model prediksi karyawan yang akan mengalami attrition. 
5. Membuat dashboard bisnis : Membuat dashboard interaktif menggunakan Tableau untuk memantau faktor-faktor yang mempengaruhi attrition secara real time.

## 4. Persiapan 

### 4.1 Sumber  : 

Dataset yang digunakan dalam proyek ini merupakan data terkait informasi karyawan yang mencakup berbagai atribut seperti umur, jenis kelamin, status pernikahan, departemen, jabatan, masa kerja, gaji, dan status attrition (keluar atau tetap). Dataset ini digunakan untuk menganalisis faktor-faktor yang mempengaruhi tingkat attrition karyawan di perusahaan.

[[🔗 Link Dataset - Employee Data]](https://github.com/dicodingacademy/dicoding_dataset/tree/main/employee) 

### 4.2 Setup Environment : 

Gunakan langkah berikut untuk mengatur lingkungan kerja : 

1. Clone Repository

```bash
git clone https://github.com/vaniard/Belajar-Penerapan-Data-Science
```
2. Setup Environment - Anaconda  
```bash
conda create --name main-ds python=3.9
conda activate main-ds
pip install -r requirements.txt
```
3. Setup Environment - Shell/Terminal
```bash
pip install pipenv
pipenv install
pipenv shell
pip install -r requirements.txt
```
4. Menjalankan File Prediksi
```bash
python prediction.py
```
5. Run Dashboard

Terdapat pada : https://public.tableau.com/views/HRAnalyticsDashboardbyVania/HRANALYTICSDASHBOARD?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link

## 5. Business Dashboard 

1. Perbandingan Karyawan Aktif dan Keluar

   Menampilkan perbandingan jumlah karyawan yang aktif bekerja dan yang telah mengundurkan diri untuk memberikan gambaran umum tentang tingkat attrition.
   
2. Attrition Berdasarkan Gender

   Mengevaluasi perbedaan jumlah karyawan yang keluar berdasarkan jenis kelamin dengan tingkat pengunduran diri.
   
3. Attrition Berdasarkan Business Travel

   Menggambarkan hubungan antara frekuensi business travel karyawan dengan tingkat pengunduran diri karyawan.
   
4. Attrition Berdasarkan Department

   Mengidentifikasi department mana saja yang memiliki tingkat pengunduran diri paling tinggi.
   
5. Attrition Berdasarkan JobRole

   Menunjukkan seberapa besar tingkat attrition di masing-masing jabatan atau posisi pekerjaan. 
   
6. Attrition Berdasarkan Education Field

    Menunjukkan hubungan antara latar belakang pendidikan karyawan dengan tingkat pengunduran diri.
   
7. Attrition Berdasarkan Over Time

   Menganalisis hubungan antara jam kerja lembur yang berlebihan dengan tingkat attrition.
   
8. Attrition Rate Berdasarkan Job Satisfaction

   Mengidentifikasi hubungan antara tingkat kepuasan terhadap pekerjaan dengan keputusan pengunduran diri.  
   
9. Attrition Rate Berdasarkan Environment Satisfaction

   Mengidentifikasi apakah kepuasan terhadap lingkungan kerja berpengaruh pada keputusan karyawan untuk keluar.

10. Attrition Berdasarkan Work Life Balance

    Menilai sejauh mana keseimbangan antara pekerjaan dan kehidupan pribadi berperan dalam keputusan untuk berhenti bekerja.

11. Attrition Berdasarkan Education

    Menampilkan hubungan antara pendidikan dan attrition. 


## 6. Conclusion

1. Tingkat Attrition
   Tingkat attrition perusahaan mencapai 16,9% dengan total 179 karyawan mengundurkan diri dari 1.058 karyawan.

2. Jenis Kelamin
   Tingkat pengunduran diri lebih tinggi terjadi pada karyawan laki-laki (male), dengan total 108 karyawan.

3. Perjalanan Bisnis
   Karyawan yang jarang melakukan perjalanan bisnis cenderung memiliki tingkat attrition lebih tinggi dibandingkan mereka yang sering berpergian untuk urusan pekerjaan.

4. Jarak Tempat Tinggal
   Faktor jarak rumah ke kantor mempengaruhi keputusan resign, di mana sebagian besar karyawan yang keluar tinggal dalam radius 0–4 km dari tempat kerja.

5. Departemen
   Departemen Research and Development (RnD) menjadi divisi dengan tingkat pengunduran diri tertinggi dibandingkan departemen lainnya.

6. Peran Pekerjaan
   Posisi sebagai Laboratory Technician merupakan jabatan dengan jumlah karyawan keluar terbanyak.

7. Distribusi Usia
   Sebagian besar karyawan yang keluar berada pada rentang usia 28–29 tahun.

8. Penghasilan Bulanan
   Karyawan dengan gaji bulanan berkisar antara 2.000–2.999 cenderung lebih banyak melakukan pengunduran diri.

9. Tarif Per Jam dan Departemen
   Pada departemen RnD, karyawan dengan gaji bulanan dan tarif per jam rendah lebih berisiko untuk keluar.

10. Bidang Pendidikan
    Karyawan dengan latar belakang pendidikan Technical Degree memiliki tingkat pengunduran diri paling tinggi.

11. Status Lembur
    Karyawan yang sering lembur menunjukkan kecenderungan lebih tinggi untuk meninggalkan perusahaan.

12. Work-Life Balance
    Mereka yang memiliki tingkat keseimbangan kehidupan kerja rendah cenderung lebih memilih untuk resign.

13. Kepuasan Lingkungan Kerja
    Karyawan dengan tingkat kepuasan terhadap lingkungan kerja paling rendah memiliki tingkat attrition hingga 0,27 atau 27%.

14. Kepuasan Kerja
    Tingkat attrition tertinggi ditemukan pada karyawan yang memiliki kepuasan kerja rendah, dengan persentase sebesar 0,22 atau 22%.

15. Masa Kerja di Perusahaan
    Mayoritas karyawan yang keluar memiliki masa kerja antara 0–4 tahun.

16. Pengalaman Kerja
    Secara rata-rata, karyawan yang keluar memiliki pengalaman kerja selama 1 tahun.

17. Tingkat Pendidikan
    Sebagian besar karyawan yang mengundurkan diri merupakan lulusan tingkat pendidikan Sarjana.

18. Latar Belakang Pendidikan
    Tingkat pengunduran diri juga dipengaruhi oleh latar belakang pendidikan, di mana bidang Technical Degree mendominasi jumlah karyawan yang keluar.

## 7. Rekomendasi Action Items 

1. Optimalisasi Work-Life Balance: Tingkatkan program yang mendukung keseimbangan antara pekerjaan dan kehidupan pribadi, seperti penerapan jam kerja yang fleksibel atau kebijakan kerja remote.

2. Peningkatan Kepuasan Environment dan Job: Ciptakan suasana kerja yang nyaman dan mendukung dengan cara rutin melakukan survei kepuasan karyawan serta menindaklanjuti temuan permasalahan yang ada.

3. Perbaikan Kebijakan Lembur: Evaluasi kembali sistem lembur dengan mengurangi beban kerja berlebih dan memberikan kompensasi yang sesuai bagi karyawan yang harus bekerja di luar jam kerja normal.

4. Pengembangan Karir untuk Karyawan Baru: Fokus pada pengembangan keterampilan dan peningkatan retensi karyawan dengan masa kerja singkat melalui program pelatihan, pendampingan (mentoring), serta proses onboarding yang lebih efektif.

5. Peninjauan Struktur Gaji: Lakukan evaluasi terhadap skema penggajian, khususnya bagi karyawan di posisi dengan penghasilan rendah, untuk menurunkan risiko pengunduran diri.

6. Prioritaskan Departemen RnD: Lakukan identifikasi terhadap penyebab tingginya attrition di departemen Research and Development, kemudian terapkan solusi yang tepat dan sesuai dengan kebutuhan.









