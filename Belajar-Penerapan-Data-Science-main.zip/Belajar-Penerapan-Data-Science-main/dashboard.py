import streamlit as st
import pandas as pd
import plotly.express as px

# Set the page config to make the layout wide
st.set_page_config(layout="wide", page_title="Employee Attrition Dashboard", page_icon="📊")

# Load dataset
# Ensure the 'employees.csv' file is in the same directory as your Streamlit app
try:
    data = pd.read_csv('employees.csv')
except FileNotFoundError:
    st.error("Error: 'employees.csv' not found. Please make sure the dataset is in the same directory.")
    st.stop()

# --- Dashboard Title and Introduction ---
st.title("📊 Employee Attrition Analysis Dashboard")
st.markdown("""
Selamat datang di Dasbor Analisis Attrition Karyawan. Dasbor ini menyediakan berbagai visualisasi untuk membantu memahami
faktor-faktor yang berkontribusi terhadap attrition karyawan. Jelajahi tab yang berbeda untuk mendapatkan wawasan tentang demografi,
faktor-faktor terkait pekerjaan, tingkat kepuasan, dan lainnya.
""")

# --- Define common colors for 'Yes' and 'No' attrition ---
ATTRITION_COLORS = {'Yes': '#FF8C00', 'No': '#1E90FF'} # Red for Yes, Green for No

# --- Visualizations (questions 1–18) ---

# 1. Comparison of Active and Exiting Employees
attrition_comparison = data['Attrition'].value_counts().reset_index()
attrition_comparison.columns = ['Attrition', 'Count']
fig1_attrition_comparison = px.bar(attrition_comparison,
                                     x='Attrition',
                                     y='Count',
                                     color='Attrition',
                                     color_discrete_map=ATTRITION_COLORS,
                                     labels={'Attrition': 'Attrition Status', 'Count': 'Number of Employees'},
                                     title="1. Perbandingan Karyawan Aktif dan Keluar",
                                     text='Count') # Display count on bars
fig1_attrition_comparison.update_traces(texttemplate='%{text}', textposition='outside')

# 2. Employees Leaving by Gender
gender_attrition = data.groupby(['Gender', 'Attrition']).size().reset_index(name='Count')
fig2_gender_attrition = px.bar(gender_attrition,
                                 x='Gender',
                                 y='Count',
                                 color='Attrition',
                                 barmode='stack',
                                 color_discrete_map=ATTRITION_COLORS,
                                 labels={'Attrition': 'Status Attrition', 'Count': 'Jumlah'},
                                 title="2. Karyawan yang Keluar berdasarkan Gender")

# 3. Attrition by Business Travel
business_travel_attrition = data.groupby(['BusinessTravel', 'Attrition']).size().reset_index(name='Count')
fig3_business_travel = px.bar(business_travel_attrition,
                                 x='BusinessTravel',
                                 y='Count',
                                 color='Attrition',
                                 barmode='stack', 
                                 color_discrete_map=ATTRITION_COLORS,
                                 labels={'Attrition': 'Status Attrition', 'Count': 'Jumlah'},
                                 title="3. Attrition berdasarkan Perjalanan Bisnis (Stacked Bar Chart)")

# 4. Effect of Distance From Home on Attrition (Yes and No)
fig4_distance_yes = px.histogram(data[data['Attrition'] == 'Yes'],
                                 x="DistanceFromHome",
                                 color="Attrition",
                                 barmode="overlay",
                                 color_discrete_map={"Yes": ATTRITION_COLORS['Yes']},
                                 title="4a. Attrition (Ya) berdasarkan Jarak dari Rumah",
                                 labels={"DistanceFromHome": "Jarak dari Rumah (mil)"})

fig4_distance_no = px.histogram(data[data['Attrition'] == 'No'],
                                x="DistanceFromHome",
                                color="Attrition",
                                barmode="overlay",
                                color_discrete_map={"No": ATTRITION_COLORS['No']},
                                title="4b. Non-Attrition (Tidak) berdasarkan Jarak dari Rumah",
                                labels={"DistanceFromHome": "Jarak dari Rumah (mil)"})

# 5. Attrition Comparison by Department
attrition_comparison_dept = data.groupby(['Department', 'Attrition']).size().reset_index(name='Count')
fig5_department_attrition = px.bar(attrition_comparison_dept,
                                     x='Department',
                                     y='Count',
                                     color='Attrition',
                                     barmode='stack',
                                     title="5. Perbandingan Attrition berdasarkan Departemen",
                                     labels={"Count": "Jumlah Karyawan", "Department": "Departemen", "Attrition": "Status Attrition"},
                                     color_discrete_map=ATTRITION_COLORS)

# 6. Attrition Count by Job Role
attrition_yes_count_jobrole = data[data['Attrition'] == 'Yes'].groupby('JobRole').size().reset_index(name='Attrition Count')
fig6_jobrole_attrition = px.bar(attrition_yes_count_jobrole,
                                 x='Attrition Count',
                                 y='JobRole',
                                 orientation='h',
                                 title='6. Jumlah Attrition berdasarkan Peran Pekerjaan (Karyawan yang keluar)',
                                 labels={'Attrition Count': 'Jumlah Attrition', 'JobRole': 'Peran Pekerjaan'},
                                 color_discrete_sequence=[ATTRITION_COLORS['Yes']])
fig6_jobrole_attrition.update_layout(yaxis={'categoryorder':'total ascending'}) # Order by count

# 7. Age Distribution by Attrition Status
fig7_age_distribution = px.histogram(data,
                                      x='Age',
                                      color='Attrition',
                                      barmode='overlay',
                                      title='7. Distribusi Usia berdasarkan Status Attrition',
                                      labels={'Attrition': 'Attrition', 'Age': 'Usia'},
                                      color_discrete_map=ATTRITION_COLORS)
fig7_age_distribution.update_layout(xaxis_title="Usia (Tahun)", yaxis_title="Jumlah Karyawan")


# 8. Monthly Income Distribution by Attrition Status
fig8_monthly_income_distribution = px.histogram(data,
                                                 x='MonthlyIncome',
                                                 color='Attrition',
                                                 barmode='overlay',
                                                 title="8. Distribusi Pendapatan Bulanan berdasarkan Status Attrition",
                                                 labels={'Attrition': 'Attrition', 'MonthlyIncome': 'Pendapatan Bulanan'},
                                                 color_discrete_map=ATTRITION_COLORS)
fig8_monthly_income_distribution.update_layout(xaxis_title="Pendapatan Bulanan ($)", yaxis_title="Jumlah Karyawan")


# 9. Relationship between Monthly Income and Hourly Rate by Attrition Status and Department
fig9_income_hourly_scatter = px.scatter(data,
                                         x='MonthlyIncome',
                                         y='HourlyRate',
                                         color='Attrition',
                                         symbol='Department',
                                         title="9. Hubungan Pendapatan Bulanan dan Tarif Per Jam berdasarkan Attrition dan Departemen",
                                         labels={'MonthlyIncome': 'Pendapatan Bulanan ($)', 'HourlyRate': 'Tarif Per Jam ($)'},
                                         color_discrete_map=ATTRITION_COLORS,
                                         hover_name="JobRole")

# 10. Attrition Rate by Education Field
attrition_by_education = data.groupby(['EducationField', 'Attrition']).size().reset_index(name='Count')
attrition_by_education['Total'] = attrition_by_education.groupby('EducationField')['Count'].transform('sum')
attrition_by_education['AttritionRate'] = attrition_by_education['Count'] / attrition_by_education['Total']
attrition_yes_education = attrition_by_education[attrition_by_education['Attrition'] == 'Yes']
fig10_education_attrition_rate = px.bar(attrition_yes_education,
                                          x='EducationField',
                                          y='AttritionRate',
                                          color='EducationField',
                                          title='10. Tingkat Attrition berdasarkan Bidang Pendidikan',
                                          labels={'AttritionRate': 'Tingkat Attrition', 'EducationField': 'Bidang Pendidikan'},
                                          color_discrete_sequence=px.colors.qualitative.Pastel)
fig10_education_attrition_rate.update_layout(yaxis_tickformat='.0%') # Format y-axis as percentage

# 11. Attrition Rate by Overtime Status
attrition_overtime = data.groupby(['OverTime', 'Attrition']).size().reset_index(name='Count')
attrition_overtime['Total'] = attrition_overtime.groupby('OverTime')['Count'].transform('sum')
attrition_overtime['AttritionRate'] = attrition_overtime['Count'] / attrition_overtime['Total']
yes_attrition_overtime = attrition_overtime[attrition_overtime['Attrition'] == 'Yes'] # Filter for 'Yes' attrition to get attrition rates

fig11_overtime_attrition_pie = px.pie(yes_attrition_overtime, # Using the filtered dataframe
                                      values='AttritionRate',
                                      names='OverTime',
                                      color='OverTime', # Color by OverTime to differentiate slices
                                      color_discrete_map={'Yes': ATTRITION_COLORS['Yes'], 'No': ATTRITION_COLORS['No']}, # Map directly to OverTime
                                      title='11. Attrition Rate berdasarkan Overtime Status (Pie Chart)')
fig11_overtime_attrition_pie.update_traces(textposition='inside', textinfo='percent+label')

# 12. Attrition Rate by Work-Life Balance
work_life_attrition_rate = data.groupby('WorkLifeBalance')['Attrition'].value_counts(normalize=True).unstack().fillna(0)
work_life_attrition_rate = work_life_attrition_rate['Yes']
fig12_worklife_attrition_rate = px.bar(work_life_attrition_rate,
                                        x=work_life_attrition_rate.index.astype(str), # Convert to string for categorical x-axis
                                        y=work_life_attrition_rate.values,
                                        labels={'x': 'Rating Keseimbangan Kehidupan Kerja (1=Buruk, 4=Terbaik)', 'y': 'Tingkat Attrition'},
                                        title="12. Tingkat Attrition berdasarkan Keseimbangan Kehidupan Kerja",
                                        color=work_life_attrition_rate.values, # Color based on rate
                                        color_continuous_scale=px.colors.sequential.Sunset)
fig12_worklife_attrition_rate.update_layout(yaxis_tickformat='.0%')


# 13. Attrition Based on Overtime
overtime_attrition = data.groupby(['OverTime', 'Attrition']).size().reset_index(name='Count')
fig13_overtime_counts = px.bar(overtime_attrition,
                                x='OverTime',
                                y='Count',
                                color='Attrition',
                                title="13. Attrition berdasarkan Overtime (Stacked Bar Chart)",
                                labels={'OverTime': 'Overtime', 'Attrition': 'Attrition', 'Count': 'Jumlah'},
                                color_discrete_map=ATTRITION_COLORS,
                                barmode='stack') # Mengubah barmode menjadi 'stack'

# 14. Attrition Rate by Environment Satisfaction
env_satisfaction_attrition_rate = data.groupby('EnvironmentSatisfaction')['Attrition'].value_counts(normalize=True).unstack().fillna(0)
env_satisfaction_attrition_rate = env_satisfaction_attrition_rate['Yes']
fig14_env_satisfaction_attrition_rate = px.bar(env_satisfaction_attrition_rate,
                                                x=env_satisfaction_attrition_rate.index.astype(str),
                                                y=env_satisfaction_attrition_rate.values,
                                                labels={'x': 'Rating Kepuasan Lingkungan (1=Rendah, 4=Tinggi)', 'y': 'Tingkat Attrition'},
                                                title="14. Tingkat Attrition berdasarkan Kepuasan Lingkungan",
                                                color=env_satisfaction_attrition_rate.values,
                                                color_continuous_scale=px.colors.sequential.Sunset)
fig14_env_satisfaction_attrition_rate.update_layout(yaxis_tickformat='.0%')


# 15. Attrition Rate by Job Satisfaction
job_satisfaction_attrition_rate = data.groupby('JobSatisfaction')['Attrition'].value_counts(normalize=True).unstack().fillna(0)
job_satisfaction_attrition_rate = job_satisfaction_attrition_rate['Yes']
fig15_job_satisfaction_attrition_rate = px.bar(job_satisfaction_attrition_rate,
                                                x=job_satisfaction_attrition_rate.index.astype(str),
                                                y=job_satisfaction_attrition_rate.values,
                                                labels={'x': 'Rating Kepuasan Kerja (1=Rendah, 4=Tinggi)', 'y': 'Tingkat Attrition'},
                                                title="15. Tingkat Attrition berdasarkan Kepuasan Kerja",
                                                color=job_satisfaction_attrition_rate.values,
                                                color_continuous_scale=px.colors.sequential.Sunset)
fig15_job_satisfaction_attrition_rate.update_layout(yaxis_tickformat='.0%')


# 16. Distribution of years of experience for employees who left (Attrition = 'Yes') and stayed (Attrition = 'No')
fig16_years_at_company_distribution = px.histogram(data,
                                                    x='YearsAtCompany',
                                                    color='Attrition',
                                                    barmode='overlay',
                                                    title="16. Distribusi Tahun di Perusahaan berdasarkan Attrition",
                                                    labels={'YearsAtCompany': 'Tahun di Perusahaan', 'Attrition': 'Attrition'},
                                                    color_discrete_map=ATTRITION_COLORS,
                                                    nbins=15)

# 17. Attrition Comparison by Work Experience (Total Working Years)
attrition_comparison_total_years = data.groupby(['TotalWorkingYears', 'Attrition']).size().unstack().fillna(0)
fig17_total_working_years_comparison = px.bar(attrition_comparison_total_years,
                                                x=attrition_comparison_total_years.index,
                                                y=['Yes', 'No'],
                                                labels={'TotalWorkingYears': 'Total Tahun Kerja', 'value': 'Jumlah'},
                                                title="17. Perbandingan Attrition berdasarkan Total Tahun Kerja (Stacked Bar Chart)",
                                                color_discrete_map={'Yes': ATTRITION_COLORS['Yes'], 'No': ATTRITION_COLORS['No']},
                                                barmode='stack') # Mengubah barmode menjadi 'stack'

# 18. Attrition Count by Education Level
attrition_counts_education_level = data.groupby('Education')['Attrition'].value_counts().unstack().fillna(0)
education_level_mapping = {
    1: '1 - Di Bawah Perguruan Tinggi',
    2: '2 - Perguruan Tinggi',
    3: '3 - Sarjana',
    4: '4 - Master',
    5: '5 - Doktor'
}
attrition_counts_education_level = attrition_counts_education_level.rename(index=education_level_mapping)

fig18_education_level_counts = px.bar(attrition_counts_education_level,
                                        x=attrition_counts_education_level.index,
                                        y=['Yes', 'No'],
                                        labels={'index': 'Tingkat Pendidikan', 'value': 'Jumlah', 'variable': 'Attrition'},
                                        title="18. Jumlah Attrition berdasarkan Tingkat Pendidikan (Stacked Bar Chart)",
                                        color='variable',
                                        color_discrete_map=ATTRITION_COLORS,
                                        barmode='stack')


# --- Streamlit Layout with Tabs ---
tab1, tab2, tab3, tab4 = st.tabs(["Ikhtisar & Demografi", "Faktor Kerja & Perjalanan", "Kepuasan & Pengalaman", "Pendapatan & Pendidikan"])

with tab1:
    st.header("Ikhtisar & Wawasan Demografi")
    st.markdown("Bagian ini mengeksplorasi pola attrition terkait gambaran umum karyawan, gender, dan usia.")
    st.plotly_chart(fig1_attrition_comparison, use_container_width=True)
    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        st.plotly_chart(fig2_gender_attrition, use_container_width=True)
    with col2:
        st.plotly_chart(fig7_age_distribution, use_container_width=True)

with tab2:
    st.header("Faktor Attrition Terkait Pekerjaan & Perjalanan")
    st.markdown("Di sini, kami menganalisis bagaimana perjalanan bisnis, jarak dari rumah, departemen, dan peran pekerjaan memengaruhi attrition.")
    st.plotly_chart(fig3_business_travel, use_container_width=True)
    st.markdown("---")
    col3, col4 = st.columns(2)
    with col3:
        st.plotly_chart(fig4_distance_yes, use_container_width=True)
    with col4:
        st.plotly_chart(fig4_distance_no, use_container_width=True)
    st.markdown("---")
    st.plotly_chart(fig5_department_attrition, use_container_width=True)
    st.markdown("---")
    st.plotly_chart(fig6_jobrole_attrition, use_container_width=True)


with tab3:
    st.header("Dampak Kepuasan & Pengalaman terhadap Attrition")
    st.markdown("Bagian ini membahas bagaimana kepuasan karyawan, keseimbangan kehidupan kerja, dan tahun pengalaman berkorelasi dengan attrition.")
    col5, col6 = st.columns(2)
    with col5:
        st.plotly_chart(fig12_worklife_attrition_rate, use_container_width=True)
    with col6:
        st.plotly_chart(fig14_env_satisfaction_attrition_rate, use_container_width=True)
    st.markdown("---")
    st.plotly_chart(fig15_job_satisfaction_attrition_rate, use_container_width=True)
    st.markdown("---")
    col7, col8 = st.columns(2)
    with col7:
        st.plotly_chart(fig16_years_at_company_distribution, use_container_width=True)
    with col8:
        st.plotly_chart(fig17_total_working_years_comparison, use_container_width=True)

with tab4:
    st.header("Attrition Terkait Pendapatan & Pendidikan")
    st.markdown("Periksa hubungan antara pendapatan bulanan, tarif per jam, pendidikan, dan attrition.")
    st.plotly_chart(fig8_monthly_income_distribution, use_container_width=True)
    st.markdown("---")
    st.plotly_chart(fig9_income_hourly_scatter, use_container_width=True)
    st.markdown("---")
    col9, col10 = st.columns(2)
    with col9:
        st.plotly_chart(fig10_education_attrition_rate, use_container_width=True)
    with col10:
        st.plotly_chart(fig18_education_level_counts, use_container_width=True)
    st.markdown("---")
    col11, col12 = st.columns(2)
    with col11:
        st.plotly_chart(fig11_overtime_attrition_pie, use_container_width=True)
    with col12:
        st.plotly_chart(fig13_overtime_counts, use_container_width=True)

st.sidebar.markdown("---")
st.sidebar.header("Tentang Dasbor Ini")
st.sidebar.info(
    "Dasbor interaktif ini dibangun menggunakan Streamlit dan Plotly untuk memvisualisasikan "
    "wawasan utama dari data karyawan, dengan fokus pada attrition. Gunakan tab di atas "
    "untuk menavigasi melalui berbagai kategori analisis."
)
st.sidebar.markdown("---")